using URLShortner.Service;

namespace URLShortner.Test
{
    [TestClass]
    public class UrlShortenerTest
    {
        public UrlShortenerTest()
        {
            
        }

        [TestMethod]
        public void LongUrlTest()
        {
            var urlShortener = new UrlShortenerService();

            // Test GenerateShortUrl
            var longUrl = "https://www.metservice.com/towns-cities/locations/auckland/7-days";
            var shortUrl = urlShortener.GenerateShortUrl(longUrl);

            // Test GetLongUrl
            var retrievedLongUrl = urlShortener.GetLongUrl(shortUrl);            

            Assert.AreEqual(longUrl, retrievedLongUrl, true);
        }
    }
}