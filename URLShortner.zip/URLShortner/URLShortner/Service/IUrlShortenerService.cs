﻿namespace URLShortner.Service
{
    public interface IUrlShortenerService
    {
        public string GenerateShortUrl(string longUrl);
        public string GetLongUrl(string shortUrl);
    }
}
