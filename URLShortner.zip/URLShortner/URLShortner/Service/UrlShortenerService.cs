﻿using System;
using System.Collections.Generic;
namespace URLShortner.Service
{
    public class UrlShortenerService: IUrlShortenerService
    {
        private Dictionary<string, string> urlMappings = new Dictionary<string, string>();

        private const string ShortUrlPrefix = "https://short.st/";

        public string GenerateShortUrl(string longUrl)
        {
            if (urlMappings.ContainsValue(longUrl))
            {
                throw new InvalidOperationException("Long URL already exists");
            }

            var key = GenerateKey();
            var shortUrl = ShortUrlPrefix + key;

            urlMappings.Add(key, longUrl);

            return shortUrl;
        }

        public string GetLongUrl(string shortUrl)
        {
            var key = shortUrl.Replace(ShortUrlPrefix, "");

            if (!urlMappings.ContainsKey(key))
            {
                throw new KeyNotFoundException("Short URL does not exist");
            }

            return urlMappings[key];
        }

        private string GenerateKey()
        {
            var guid = Guid.NewGuid();
            return Convert.ToBase64String(guid.ToByteArray())
                   .Replace("/", "")
                   .Replace("+", "")
                   .Substring(0, 6);
        }
    }

}
