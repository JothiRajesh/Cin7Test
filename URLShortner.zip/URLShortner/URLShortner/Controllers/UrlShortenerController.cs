﻿using Microsoft.AspNetCore.Mvc;
using URLShortner.Service;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace URLShortner.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UrlShortenerController : ControllerBase
    {
        private IUrlShortenerService _urlShortenerService;
        public UrlShortenerController(IUrlShortenerService urlShortenerService) 
        {
            _urlShortenerService = urlShortenerService;
        }

        [HttpGet(Name ="GenerateShortUrl")]
        public string GenerateShortUrl(string url)
        {
            return _urlShortenerService.GenerateShortUrl(url);            
        }

        [HttpGet(Name ="GetLongUrl")]
        public string GetLongUrl(string shortUrl)
        {
            return _urlShortenerService.GetLongUrl(shortUrl);
        }
    }
}
